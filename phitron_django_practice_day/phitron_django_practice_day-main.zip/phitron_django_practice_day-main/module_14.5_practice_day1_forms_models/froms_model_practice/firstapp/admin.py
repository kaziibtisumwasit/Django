from django.contrib import admin
from . models import Studentmodel
# Register your models here.
admin.site.register(Studentmodel)